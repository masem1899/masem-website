



export default function() {
    return (
        <section id="projects" className="py-20 text-center bg-muted text-foreground">
            <h2 className="text-3xl font-bold mb-4">Projects</h2>
            <p className="text-muted-foreground">Coming soon... Stay tuned!</p>
        </section>
    );
}